using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Unipal.Model.Modules {
    public enum MarkType {
        Workshop = 0,
        Exam = 1,
        Assignment = 2
    }
}
